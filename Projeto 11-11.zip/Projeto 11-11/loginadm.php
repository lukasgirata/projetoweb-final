<?php
// Iniciar sessão
session_start();

// Configurações de conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "form";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Variável para armazenar erro
$erro = "";

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['password'];

    // Consulta parametrizada para prevenir SQL Injection
    $sql = "SELECT * FROM pessoas WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        
        // Verificar a senha diretamente
        if ($senha == $row['senha']) {
            // Verificação específica para o admin
            if ($email == "admctrobots@gmail.com") {
                $_SESSION['admin_logado'] = true;
                header("Location: adm.html");
                exit();
            } else {
                $erro = "Acesso não autorizado";
            }
        } else {
            $erro = "Email ou senha incorretos";
        }
    } else {
        $erro = "Email ou senha incorretos";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Administração</title>
    <link rel="stylesheet" href="style-loginadm.css">
</head>
    
<body>
    <header>
        <img src="imagens-index/logo.png" width="150px" style="text-align: center;">
        <br>
        <div style="color: white; text-align: center; text-decoration: none;" id="nav">
            <a id="inicio" href="index.html">Início</a>
            <a>/</a>
            <a>Login de Adm</a>
        </div>
        <style>
            a {
                text-decoration: none;
                color: rgb(197, 197, 197);
                font-size: 17px;
            }
        </style>
        <br>
        <h1>Login da Administração</h1>
    </header>

    <br><br>

    <div class="container">
        <?php
        // Mostrar mensagem de erro se houver
        if (!empty($erro)) {
            echo "<p style='color: red; text-align: center;'>$erro</p>";
        }
        ?>
        <form method="POST" action="">
            <label for="email">Email de acesso:</label>
            <input type="email" name="email" id="email" placeholder="Ex: adm@gmail.com" required>

            <br><br>

            <label for="password">Senha:</label>
            <input type="password" name="password" id="password" required>

            <br><br>

            <button type="submit">Entrar</button>
        </form>
    </div>
</body>
</html>