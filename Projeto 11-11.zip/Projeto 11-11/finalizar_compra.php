<?php

    include "conexao.php";

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $produtos = json_decode($_POST['produtos'], true);
        if ($produtos === null) {
            echo json_encode(["status" => "error", "message" => "Invalid JSON"]);
            exit();
        }
    
        foreach ($produtos as $produto => $quantidade) {
            $sql = "UPDATE estoque SET quantidade = quantidade - ? WHERE produto = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                echo json_encode(["status" => "error", "message" => "SQL error: " . $conn->error]);
                exit();
            }
            $stmt->bind_param("is", $quantidade, $produto);
            if (!$stmt->execute()) {
                echo json_encode(["status" => "error", "message" => "Execution error: " . $stmt->error]);
                exit();
            }
        }
    
        $stmt->close();
        $conn->close();
    
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid request method"]);
    }
    ?>