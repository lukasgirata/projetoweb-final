
<?php
    $servidor = "localhost";
            $usuario = "root";
            $senha = "";
            $bd = "form";

            if($conn = new mysqli($servidor, $usuario, $senha, $bd)){
                    //echo "Conectado";
            }else{
                echo "Erro de conexão<br>";
            }    
?>