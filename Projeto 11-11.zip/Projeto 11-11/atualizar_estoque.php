<?php
header('Content-Type: application/json');

try {
    if (!isset($_POST['produto-id'], $_POST['produto-nome'], $_POST['produto-quantidade'], $_POST['produto-preco'])) {
        throw new Exception('Dados incompletos');
    }

    $id = intval($_POST['produto-id']);
    $nome = $_POST['produto-nome'];
    $quantidade = intval($_POST['produto-quantidade']);
    $preco = floatval($_POST['produto-preco']);

    $dsn = 'mysql:host=localhost;dbname=form';
    $username = 'root';
    $password = '';

    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('UPDATE estoque SET produto = :nome, quantidade = :quantidade, preco = :preco WHERE id = :id');
    $stmt->execute([':nome' => $nome, ':quantidade' => $quantidade, ':preco' => $preco, ':id' => $id]);

    echo json_encode(['status' => 'success']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
