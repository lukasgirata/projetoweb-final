<?php
    session_start(); 
    include "conexao.php";

    $email = $_POST['email'];
    $senha = md5($_POST['senha']);

    $sql = "SELECT * FROM pessoas WHERE email = '$email' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['email'] = $email; 
        echo "Login bem-sucedido!";
        echo '<br><a href="index.html">Clique aqui para retornar à página inicial</a>';
    } else {
        echo "E-mail ou senha incorretos!";
    }

    echo "<script>localStorage.setItem('email', '$email');</script>";

    $conn->close();
?>