<?php
// Configurações de conexão com o banco de dados
$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'form';

// Conectar ao banco de dados
$conexao = mysqli_connect($host, $usuario, $senha, $banco);

// Verificar conexão
if (!$conexao) {
    die("Erro de conexão: " . mysqli_connect_error());
}

// Função para finalizar compra
function finalizarCompra($produtos) {
    global $conexao;
    mysqli_begin_transaction($conexao);

    try {
        foreach ($produtos as $produto => $quantidade) {
            // Verificar estoque disponível
            $consulta = "SELECT quantidade FROM estoque WHERE produto = '$produto'";
            $resultado = mysqli_query($conexao, $consulta);
            $estoque = mysqli_fetch_assoc($resultado);

            if ($estoque['quantidade'] < $quantidade) {
                throw new Exception("Estoque insuficiente para $produto");
            }

            // Subtrair quantidade do estoque
            $update = "UPDATE estoque SET quantidade = quantidade - $quantidade WHERE produto = '$produto'";
            mysqli_query($conexao, $update);
        }

        mysqli_commit($conexao);
        return ['status' => 'success', 'message' => 'Compra finalizada'];
    } catch (Exception $e) {
        mysqli_rollback($conexao);
        return ['status' => 'error', 'message' => $e->getMessage()];
    }
}

// Processar finalização de compra via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['produtos'])) {
    $produtos = json_decode($_POST['produtos'], true);
    echo json_encode(finalizarCompra($produtos));
    exit;
}

// Buscar informações de estoque
$consulta = "SELECT produto, quantidade, preco FROM estoque WHERE produto IN ('defender', 'keeper', 'striker')";
$resultado = mysqli_query($conexao, $consulta);

$estoque = [];
while ($linha = mysqli_fetch_assoc($resultado)) {
    $estoque[$linha['produto']] = [
        'quantidade' => $linha['quantidade'],
        'preco' => $linha['preco']
    ];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8"/>
    <title>Carrinho de Compras CT Robots</title>
    <link rel="stylesheet" href="styles.scss" />
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        a {
            text-decoration: none;
            color: rgb(197, 197, 197);
            font-size: 17px;
        }
        #finalizar {
            cursor: pointer;
            background-color: rgba(77, 169, 77, 0.877);
            padding: 20px;
            padding-block: 12px;
            border-radius: 5px;
            box-shadow: 0 0 0 0;
            outline: 0;
            border: 0 none;
            font-size: 15;
        }
    </style>
</head>
<body>
    <header>
        <img src="imagens-index/logo.png" width="150px" style="text-align: center;">
        <div style="color: white; text-align: center; text-decoration: none;" id="nav">
            <a href="index.html">Início</a>
            <a>/</a>
            <a>Carrinho de compras</a>
        </div>

        <br>

        <span>Carrinho de Compras do <b>CT Robots</b></span>
    </header>
    
    <main>
        <div class="page-title">Seu Carrinho</div>
        <div class="content">
            <section>
                <table>
                    <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Preço</th>
                            <th>Em Estoque</th>
                            <th>Quantidade</th>
                            <th>Total</th>
                            <th>-</th>
                        </tr>
                    </thead>
                    <tbody id="cart-items">
                        <?php foreach(['defender', 'keeper', 'striker'] as $produto): ?>
                        <tr>
                            <td>
                                <div class="product">
                                    <img src="imagens-modelos/<?= $produto ?>2.png" alt="<?= $produto ?>" width="150px">
                                    <div class="info">
                                        <div class="name"><?= ucfirst($produto) ?></div>
                                        <div class="category">Robô</div>
                                    </div>
                                </div>
                            </td>
                            <td>R$ <?= number_format($estoque[$produto]['preco'], 2, ',', '.') ?></td>
                            <td id="<?= $produto ?>-stock"><?= $estoque[$produto]['quantidade'] ?></td>
                            <td>
                                <div class="qty">
                                    <button onclick="decreaseQuantity('<?= $produto ?>', this, <?= $estoque[$produto]['quantidade'] ?>)"><i class="bx bx-minus"></i></button>
                                    <span id="<?= $produto ?>-qty">0</span>
                                    <button onclick="increaseQuantity('<?= $produto ?>', this, <?= $estoque[$produto]['quantidade'] ?>)"><i class="bx bx-plus"></i></button>
                                </div>
                            </td>
                            <td>
                                <span id="<?= $produto ?>-total">R$ 0,00</span>
                            </td>
                            <td>
                                <button class="remove" onclick="removeProduct(this, '<?= $produto ?>')"><i class='bx bx-x'></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
            
            <aside>
                <div class="box">
                    <header>Resumo da compra</header>
                    <div class="info">
                        <div><span>Sub-Total</span><span id="sub-total">R$ 0,00</span></div>
                        <div><span>Desconto</span><span id="discount">R$ 0,00</span></div>
                        <div><span>Frete</span><span>Gratuito</span></div>
                        <div>
                            <input type="text" id="discount-code" placeholder="Adicionar cupom de desconto" />
                            <button onclick="applyDiscount()">Aplicar</button>
                        </div>
                    </div>
                    <footer>
                        <span>Total</span>
                        <span id="total">R$ 0,00</span>
                    </footer>
                </div>
                <button id="finalizar" onclick="finalizarCompra()">Finalizar Compra</button>
            </aside>
        </div>
    </main>

    <script>
        const PRODUCT_PRICES = {
            'defender': <?= $estoque['defender']['preco'] ?>,
            'keeper': <?= $estoque['keeper']['preco'] ?>,
            'striker': <?= $estoque['striker']['preco'] ?>
        };

        function increaseQuantity(product, button, maxStock) {
            const quantitySpan = button.parentNode.querySelector(`#${product}-qty`);
            let quantity = parseInt(quantitySpan.textContent);
            if (quantity < maxStock && quantity < 10) {
                quantity++;
                quantitySpan.textContent = quantity;

                const totalSpan = button.parentNode.parentNode.nextElementSibling.querySelector(`#${product}-total`);
                totalSpan.textContent = `R$ ${(quantity * PRODUCT_PRICES[product]).toFixed(2)}`;

                updateSubtotal();
                updateDiscount();
            }
        }

        function decreaseQuantity(product, button, maxStock) {
            const quantitySpan = button.parentNode.querySelector(`#${product}-qty`);
            let quantity = parseInt(quantitySpan.textContent);
            if (quantity > 0) {
                quantity--;
                quantitySpan.textContent = quantity;

                const totalSpan = button.parentNode.parentNode.nextElementSibling.querySelector(`#${product}-total`);
                totalSpan.textContent = `R$ ${(quantity * PRODUCT_PRICES[product]).toFixed(2)}`;

                updateSubtotal();
                updateDiscount();
            }
        }

        function updateSubtotal() {
            let subtotal = 0;
            for (const product in PRODUCT_PRICES) {
                const quantity = parseInt(document.querySelector(`#${product}-qty`).textContent);
                subtotal += quantity * PRODUCT_PRICES[product];
            }
            document.querySelector('#sub-total').textContent = `R$ ${subtotal.toFixed(2)}`;
            document.querySelector('#total').textContent = `R$ ${subtotal.toFixed(2)}`;
        }

        function updateDiscount() {
            let subtotal = parseFloat(document.querySelector('#sub-total').textContent.replace('R$', '').replace(',', ''));
            let discount = 0;
            const discountCode = document.querySelector('#discount-code').value;
            if (discountCode === 'CIT10') {
                discount = subtotal * 0.1;
            }
            document.querySelector('#discount').textContent = `R$ ${discount.toFixed(2)}`;
            document.querySelector('#total').textContent = `R$ ${(subtotal - discount).toFixed(2)}`;
        }

        function applyDiscount() {
            updateDiscount();
        }

        function removeProduct(button, product) {
            const row = button.closest('tr');
            row.querySelector(`#${product}-qty`).textContent = 0;
            row.querySelector(`#${product}-total`).textContent = 'R$ 0,00';
            updateSubtotal();
            updateDiscount();
        }

        function finalizarCompra() {
            const produtos = {};
            for (const product in PRODUCT_PRICES) {
                const quantity = parseInt(document.querySelector(`#${product}-qty`).textContent);
                if (quantity > 0) {
                    produtos[product] = quantity;
                }
            }

            fetch('', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    produtos: JSON.stringify(produtos)
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Compra finalizada com sucesso!');
                    window.location.reload();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Erro ao finalizar a compra. Tente novamente.');
            });
        }
    </script>
</body>
</html>