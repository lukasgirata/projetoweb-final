<?php

    include "conexao.php";

    $nome = $_POST['nome'];
    $sobre = $_POST['sobre'];
    $email = $_POST['email'];
    $cpf = $_POST['cpf'];
    $senha = $_POST['senha'];
    $data = $_POST['data'];
    $endereco = $_POST['endereco'];
    $numero = $_POST['numero'];
    $complemento = $_POST['complemento'];

    $sql = "INSERT INTO `pessoas` (`nome`, `sobrenome`, `email`, `cpf`, `senha`, `data`, `endereco`, `numero`, `complemento`) 
    VALUES ('$nome', '$sobre', '$email', '$cpf', '$senha', '$data', '$endereco', '$numero', '$complemento')";
    
    if(mysqli_query($conn, $sql)){
        echo "$nome cadastrado com sucesso";
        echo '<br><a href="index.html">Clique aqui para retornar à página inicial</a>';
    }else{
        echo "$nome não foi possível ser cadastrado";
    }

?>