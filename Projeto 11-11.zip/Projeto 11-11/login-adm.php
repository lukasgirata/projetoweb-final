<?php
session_start();

// Configurações de conexão com o banco de dados
$servername = "localhost";
$username = "root";  // Normalmente o padrão é root
$password = "";      // Senha do banco de dados (geralmente em branco no xampp/wamp)
$dbname = "form";    // Nome do banco de dados conforme o arquivo SQL

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['password'];
    
    // Hash da senha para comparação (usando MD5, que foi usado no banco)
    $senha_hash = md5($senha);

    // Consulta parametrizada para prevenir SQL Injection
    $sql = "SELECT * FROM pessoas WHERE email = ? AND senha = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $senha_hash);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // Login correto para administrador específico
        if ($email == "admctrobots@gmail.com") {
            $_SESSION['admin_logado'] = true;
            header("Location: adm.html");
            exit();
        } else {
            // Email existe, mas não é o admin
            $erro = "Acesso não autorizado";
        }
    } else {
        // Login inválido
        $erro = "Email ou senha incorretos";
    }

    $stmt->close();
}

$conn->close();
?>